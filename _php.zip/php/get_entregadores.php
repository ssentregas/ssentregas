﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT id_entregador ,nm_entregador FROM entregador");
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

echo json_encode($result);

?>
