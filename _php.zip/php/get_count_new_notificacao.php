﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

date_default_timezone_set('America/Sao_Paulo');

session_start();

$avisar = false;

if(isset($_SESSION['ultima_atualizacao'])){

	$from_time = strtotime($_SESSION['ultima_atualizacao']);
	$to_time = strtotime(date("Y-m-d H:i:s"));

	if(round(abs($to_time - $from_time) / 60,2) > 5)
	{
		$avisar = true;
		$_SESSION['ultima_atualizacao'] = date("Y-m-d H:i:s");
	}	
}
else
	$_SESSION['ultima_atualizacao'] = date("Y-m-d H:i:s");


$stmt = $conn->prepare("SELECT * FROM notificacao WHERE dt_visualizado is Null AND dt_inclusao > CURDATE()");
$stmt->execute();

$res = $stmt->fetchAll(PDO::FETCH_CLASS);
$notificacoes = array(); 

foreach ($res as $notificacao) {
	$notificacoes[$notificacao->tx_descricao.' ('.$notificacao->ds_titulo.')'] = array(
		'texto' => $notificacao->tx_descricao.' ('.$notificacao->ds_titulo.')',
	);
}

$qtd = count($notificacoes);

$avisar = $qtd > 0 && $avisar;

echo json_encode(array('notificacoes'=>$notificacoes,'qtd'=>$qtd,'avisar'=>$avisar));

?>