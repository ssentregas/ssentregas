﻿<?php

$id = $_POST['id'];
$nm = $_POST['nm'];

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT nm_fantasia FROM entregador WHERE id_entregador = ?");	  
$stmt->execute(array($id));
$nome = $stmt->fetch();

$stmt = $conn->prepare("SELECT id_usuario, now() as dt FROM usuario WHERE login=?");	  
$stmt->execute(array($nm));
$id_u = $stmt->fetch();

$cp=array('nm'=>$nome['nm_fantasia'],'id'=>$id_u['id_usuario'],'dt'=>$id_u['dt']);
echo json_encode($cp);

?>