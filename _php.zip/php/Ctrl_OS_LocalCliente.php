﻿<?php
header('Access-Control-Allow-Origin: http://ssentregas.com.br');  
include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$base = buscaBaseMaisProxima($conn,$_POST['trajetos'][0]);

$stmt = $conn->prepare("SELECT tarifa_item.* FROM tarifa INNER JOIN tarifa_item ON tarifa_item.id_tarifa = tarifa.id_tarifa WHERE tarifa.id_tarifa = ?");
$stmt->execute(array(3));
$tarifa_item = $stmt->fetchAll();

$regra_tarifa = array();
foreach ($tarifa_item as $tarifa_item) {
	$regra_tarifa[$tarifa_item['apartir_trajeto']] = array('tarifa_min' => floatval($tarifa_item['qtd_faixa_tarifa_min']), 'valor_km' => floatval($tarifa_item['vlr_tipo_tarifa']));
}

function buscaBaseMaisProxima($conn,$destino){
	$stmtx = $conn->prepare("SELECT * FROM local_padrao");
	$stmtx->execute();
	$query_base = $stmtx->fetchAll();
	$y = '';
	$return = '';

	foreach ($query_base as $base) {
		$x = consultaGoogle($base['ds_endereco_completo'],$destino);
		
		$valida = empty($y) ? true : $x['distance']['value'] < $y['distance']['value'];

		if($valida){
			$y = $x;
			$return = $base['ds_endereco_completo'];
		}
	}

	return $return;
}

function consultaGoogle($origem,$destino){

	$cp_result=urlencode($origem).'&destinations='.urlencode($destino);

	$url='https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$cp_result.'&key=AIzaSyCoa2nY5o8Hs5HlRleViH7kFV9qlkRDTZE';

	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_HEADER, false);
	$data = curl_exec($curl);
	curl_close($curl);
	if($data === FALSE) {
	    die(curl_error($ch));
	}
	else {
	    $r = json_decode($data);
	  
	    $ret = array();
	    $e = $r->rows[0]->elements[0];

	    $ret['distance'] = array('text'=>$e->distance->text,'value'=>($e->distance->value/1000));

	    $duration = $e->duration->value/2;
	    $ret['duration'] = array('text'=>$e->duration->text,'value'=>$e->duration->value+$duration);

	    return $ret;
	}
}

$origem = $base;

$total_distancia = 0;
$total_tempo = 0;

$km_total_rota = 0;

$tarifa_min = $regra_tarifa[0]['tarifa_min'];
$valor_km   = $regra_tarifa[0]['valor_km'];
$i = 0;

foreach ($_POST['trajetos'] as $trajeto) {

	$ret[$trajeto['index']] = consultaGoogle($origem,$trajeto['value']);

	if($base != $origem) {

		if(isset($regra_tarifa[$i])){
			$tarifa_min = $regra_tarifa[$i]['tarifa_min'];
			$valor_km   = $regra_tarifa[$i]['valor_km'];
		}

		$total_distancia += $ret[$trajeto['index']]['distance']['value'];
		$total_tempo     += $ret[$trajeto['index']]['duration']['value'];
	}

	$km_ponto_a_ponto = $ret[$trajeto['index']]['distance']['value'] > $tarifa_min ? $ret[$trajeto['index']]['distance']['value'] : $tarifa_min;
	

	$valor_total   += $km_ponto_a_ponto*$valor_km;

	//$ret[$trajeto['index']]['km_ponto_a_ponto'] = $km_ponto_a_ponto;
	//$ret[$trajeto['index']]['valor_ponto'] = $km_ponto_a_ponto*$valor_km;

	$origem = $trajeto['value'];

	$i++;
}

$retorno = consultaGoogle($origem,$base);
$km_ponto_a_ponto = $retorno['distance']['value'] > $regra_tarifa[0]['tarifa_min'] ? $retorno['distance']['value'] : $regra_tarifa[0]['tarifa_min'];

$valor_total += $km_ponto_a_ponto*$regra_tarifa[0]['valor_km'];

// CALCULO DE PREÇO FIXO, É NECESSÁRIO GUARDAR AS INFORMAÇÕES DE CADA PONTO DO TRAJETO.. MESMO EXISTINDO
if(count($_POST['trajetos']) == 2) {

	$origem  = array_reverse(explode(' - ', $_POST['trajetos'][0]['value']));
	$destino = array_reverse(explode(' - ', $_POST['trajetos'][1]['value']));

	$stmt_pro = $conn->prepare("SELECT * FROM promocao WHERE (ds_origem = :ds_origem AND ds_destino = :ds_destino) OR (ds_origem = :ds_destino AND ds_destino = :ds_origem)");
	
	$stmt_pro->bindParam(':ds_origem', $origem[1], PDO::PARAM_STR); 
	$stmt_pro->bindParam(':ds_destino', $destino[1], PDO::PARAM_STR); 
	$stmt_pro->execute();

	$preco_fixo = $stmt_pro->fetch();
	
	if(!empty($preco_fixo)){
		$valor_total = floatval($preco_fixo['vl_promocao']);	
	}
	
}

$minutos = ceil($total_tempo/60);
$tempo  = floor($minutos/60).':'.$minutos%60;

$return = array(
	'trajetos' 		  => $ret,
	'retorno'  		  => $retorno,
	'total_tempo' 	  => $tempo,
	'total_distancia' => str_replace(".",",",$total_distancia),
	'valor_total'     => number_format(floor($valor_total),2,',','.')
);

echo json_encode($return);

?>
