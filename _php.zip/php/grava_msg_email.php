<?php

	header('Content-Type: text/html; charset=utf-8');

	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$mensagem = $_POST['assunto'];
	
	$con=mysql_connect("localhost", "adm", "adm10m")
	  or die("Unable to connect to MySQL");
	  
	$db_selected = mysql_select_db('sbmcpe', $con);
	if (!$db_selected) {die ('Can\'t use Database : ' . mysql_error());}	
	
	$result = mysql_query("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'", $con);

	$result = mysql_query("SELECT * FROM email WHERE nm_email = '$email' and  ds_assunto = '$mensagem'", $con);
	$num_rows = mysql_num_rows($result);	
	
	if ($num_rows > 0)
		{
		echo "<script>alert('ATENCAO!!! Seu e-mail ja estava em nossa base de dados.')</script>";
		echo "<script> window.location.href = 'http://www.shop.med.br/sbmcpe/VII/'; </script>";
		}
	else
		{
			
            mysql_query("INSERT INTO mensagem (nm_nome, nm_email, ds_assunto, dt_inclusao)
            VALUES ('$nome', '$email', '$mensagem', now())");
            $id = mysql_insert_id();
            mysql_query("COMMIT");
			
			echo "<script>alert('Sua mensagem recebida com sucesso !!! ')</script>";
			echo "<script> window.location.href = 'http://www.shop.med.br/sbmcpe/VII/'; </script>";			

            }

?>			
