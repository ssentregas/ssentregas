﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT *,entregador.id_entregador as entregador,DATE_FORMAT(previsao_trajeto,'%d/%m/%Y %H:%i') as previsao_trajeto,DATE_FORMAT(previsao_retorno,'%d/%m/%Y %H:%i') as previsao_retorno  FROM entregador LEFT JOIN trajeto ON id_trajeto_atual = id_trajeto");

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

$na_base = array();
$em_transito = array();

foreach ($result as $motoboy) {

	$data = array(
		'nm_entregador' => $motoboy->nm_entregador,
		'qt_os_iniciada' => $motoboy->qt_os_iniciada,
		'qt_os_finalizada' => $motoboy->qt_os_finalizada,
		'qt_os_pausada' => $motoboy->qt_os_pausada
	);

	
	if($motoboy->previsao_retorno == '00/00/0000 00:00') {
		$na_base[] = $data;
		continue;
	}
	
	$data['ordem_serv'] = '';

	$data['previsao_retorno'] = $motoboy->previsao_retorno;
		$data['cp_ordem'] = '';


	if($motoboy->id_trajeto_atual != 0){

		$stmt = $conn->prepare("SELECT cp_ordem,nu_ordem_serv FROM trajeto INNER JOIN ordem_serv ON ordem_serv.id_ordem_serv = trajeto.id_ordem_serv WHERE trajeto.id_ordem_serv = :id_ordem_serv AND st_os <> 'CANCELADO' ORDER BY cp_ordem DESC");
		$stmt->bindParam(':id_ordem_serv', $motoboy->id_ordem_serv, PDO::PARAM_INT); 
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_CLASS);

		$data['ordem_serv'] = $result[0]->nu_ordem_serv;

		$tipo = 3; // 

		if($result[0]->cp_ordem == $motoboy->cp_ordem){
			$data['cp_ordem'] = 'ultimo';
			$tipo = 1;
		}
		else if($result[1]->cp_ordem == $motoboy->cp_ordem){
			$data['cp_ordem'] = 'penultimo';
			$tipo = 2;
		}
		
		$data['ponto'] = $motoboy->ds_endereco.' | '.$motoboy->previsao_trajeto;
	}
	else{
		$stmt = $conn->prepare("SELECT nu_ordem_serv FROM ordem_serv WHERE id_entregador = :id_entregador ORDER BY dt_ult_mov DESC");
		$stmt->bindParam(':id_entregador', $motoboy->entregador, PDO::PARAM_INT); 
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_CLASS);

		$tipo = 0;
		$data['cp_ordem'] = 'voltando';

		$data['ordem_serv'] = $result[0]->nu_ordem_serv;
		$data['ponto'] = 'Voltando para a base';
	}	

	//$ponto = explode(' - ', $motoboy->ds_endereco);
	$em_transito[$tipo][] = $data;
}

echo json_encode(array('na_base' => $na_base, 'em_transito' => $em_transito));

?>
