﻿<?php
include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT id_centro_custo as id, ds_centro_custo as text FROM centro_custo WHERE id_cliente = :id_cliente");
$stmt->bindParam(':id_cliente', $_POST['id'], PDO::PARAM_INT); 

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

echo json_encode($result);

?>
