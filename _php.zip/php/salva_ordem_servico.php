﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$campos = array();

$campos[] = 'id_cliente'; // ID CLIENTE
$campos[] = 'id_tarifa'; // ID TARIFA
$campos[] = 'id_forma_pagto'; // ID FORMA PAGAMENTO
$campos[] = 'nu_ordem_serv'; // NU ORDEM SERVIÇO
$campos[] = 'id_centro_custo'; // ID CENTRO CUSTO
$campos[] = 'id_entregador'; // ID ENTREGADOR
$campos[] = 'observacao'; // OBSERVACAO
$campos[] = 'nm_solicitante'; // OBSERVACAO
//$campos[] = 'id_partida_padrao'; // ID PARTIDA PADRAO
//$campos[] = 'id_retorno_padrao'; // ID RETORNO PADRAO
//$campos[] = 'dt_inicio'; // DT INICIO
$campos[] = 'dt_agendado'; // DT AGENDADO
$campos[] = 'hr_agendado'; // HR AGENDADO
$campos[] = 'nu_distancia'; // DISTANCIA TOTAL
$campos[] = 'nu_duracao'; // DURACAO TOTAL
$campos[] = 'vlr_os_previsto'; // VLR OS PREVISTO
$campos[] = 'dt_inclusao'; // DT INCLUSAO
$campos[] = 'nm_usuario'; // NM USUARIO
$campos[] = 'st_os'; // ST OS
$campos[] = 'st_pagamento'; // ST PAGAMENTO
$campos[] = 'vlr_os_final';
$campos[] = 'vl_troco';
$campos[] = 'id_tipo_pagto';

$campos_values = array();

foreach ($campos as $key => $value) {
	$campos_values[] = $value == 'dt_inclusao' ? 'now()' : ':'.$value;
}

$stmt = $conn->prepare("INSERT INTO ordem_serv (".implode(',',$campos).") VALUES (".implode(',', $campos_values).")");

$stmt->bindParam(':id_cliente', $_POST['cliente'], PDO::PARAM_INT); 
$stmt->bindParam(':id_tarifa', $_POST['id_tarifa'], PDO::PARAM_INT); 
$stmt->bindParam(':id_forma_pagto', $_POST['forma_pagamento'], PDO::PARAM_INT); 
$stmt->bindParam(':id_centro_custo', $_POST['centro_custo'], PDO::PARAM_INT); 
$stmt->bindParam(':id_entregador', $_POST['entregador'], PDO::PARAM_INT); 
$stmt->bindParam(':observacao', $_POST['observacao'], PDO::PARAM_STR); 
$stmt->bindParam(':nu_ordem_serv', $_POST['nu_ordem_serv'], PDO::PARAM_STR); 

//$stmt->bindParam(':id_partida_padrao', $_POST['partida'], PDO::PARAM_STR); 
//$stmt->bindParam(':id_retorno_padrao', $_POST['retorno'], PDO::PARAM_STR); 
//$stmt->bindParam(':dt_inicio', $_POST['inicio'], PDO::PARAM_STR); 

$data = explode('/', $_POST['dt_agendado']);
$data = $data[2].'-'.$data[1].'-'.$data[0];


$stmt->bindParam(':nm_solicitante', $_POST['solicitante'], PDO::PARAM_STR); 
$stmt->bindParam(':dt_agendado', $data, PDO::PARAM_STR); 
$stmt->bindParam(':hr_agendado', $_POST['hr_agendado'], PDO::PARAM_STR); 
$stmt->bindParam(':nu_distancia', $_POST['distancia_total'], PDO::PARAM_INT); 
$stmt->bindParam(':nu_duracao', $_POST['duracao_total'], PDO::PARAM_INT); 
$stmt->bindParam(':vlr_os_previsto', $_POST['vlr_os_previsto'], PDO::PARAM_INT); 
$stmt->bindParam(':vlr_os_final', $_POST['vlr_os_final'], PDO::PARAM_INT); 

$stmt->bindParam(':id_tipo_pagto', $_POST['id_tipo_pagto'], PDO::PARAM_INT); 

$troco = null;
$id_tipo_pagto = null;

if($_POST['forma_pagamento'] == 3){
	$troco = $_POST['vl_troco'];
	$id_tipo_pagto = $_POST['id_tipo_pagto'];
}

$stmt->bindParam(':vl_troco', $troco, PDO::PARAM_INT); 
$stmt->bindParam(':id_tipo_pagto', $id_tipo_pagto, PDO::PARAM_INT); 

$nm_usuario = 'Admin';
$st_os = 'AGUARDANDO';
$st_pagamento = 'AGUARDANDO';

$stmt->bindParam(':nm_usuario', $nm_usuario, PDO::PARAM_STR); 
$stmt->bindParam(':st_os', $st_os, PDO::PARAM_STR); 
$stmt->bindParam(':st_pagamento', $st_pagamento, PDO::PARAM_STR); 

$res = $stmt->execute();

$id_ordem_serv = $conn->lastInsertId();

if(!$res) {
	echo 'Erro ao salvar a Ordem de Serviço';
	die();
}

$campos = array();
$campos[] = 'id_cliente';
$campos[] = 'id_ordem_serv';
$campos[] = 'id_entregador';
$campos[] = 'cp_ordem';
$campos[] = 'ds_endereco';
$campos[] = 'ds_complemento';
$campos[] = 'ds_pagamento';
$campos[] = 'nm_contato';
$campos[] = 'nu_documento';
$campos[] = 'ds_observacao';
$campos[] = 'nu_distancia';
$campos[] = 'nu_duracao';
$campos[] = 'st_ordem_serv_item';
$campos[] = 'nm_usuario';
//$campos[] = 'dt_inclusao';

$campos_values = array();

foreach ($campos as $key => $value) {
	$campos_values[] = ':'.$value;
}

foreach ($_POST['trajetos'] as $trajeto) {
	
	//$campos_values[] = $trajeto == 'dt_inclusao' ? 'now()' : ':'.$trajeto;
	try{
		$stmtx = $conn->prepare("INSERT INTO trajeto (".implode(',',$campos).") VALUES (".implode(',', $campos_values).")");

		$stmtx->bindParam(':id_cliente', $_POST['cliente'], PDO::PARAM_INT);
		$stmtx->bindParam(':id_ordem_serv', $id_ordem_serv, PDO::PARAM_INT);

		$stmtx->bindParam(':id_entregador', $_POST['entregador'], PDO::PARAM_INT);
		$stmtx->bindParam(':cp_ordem', $trajeto['ordem'], PDO::PARAM_INT);
		$stmtx->bindParam(':ds_endereco', $trajeto['endereco'], PDO::PARAM_INT);
		$stmtx->bindParam(':ds_complemento', $trajeto['complemento'], PDO::PARAM_STR);
		$stmtx->bindParam(':ds_pagamento', $trajeto['pagamento'], PDO::PARAM_STR);

		$stmtx->bindParam(':nm_contato', $trajeto['contato'], PDO::PARAM_STR);
		$stmtx->bindParam(':nu_documento', $trajeto['documento'], PDO::PARAM_STR);
		
		$stmtx->bindParam(':ds_observacao', $trajeto['observacao'], PDO::PARAM_STR);
		$stmtx->bindParam(':nu_distancia', $trajeto['distancia'], PDO::PARAM_INT);
		$stmtx->bindParam(':nu_duracao', $trajeto['tempo'], PDO::PARAM_INT);

		$st_ordem_serv_item = 'AGUARDANDO';
		$nm_usuario = 'Admin';

		$stmtx->bindParam(':st_ordem_serv_item', $st_ordem_serv_item, PDO::PARAM_STR);
		$stmtx->bindParam(':nm_usuario', $nm_usuario, PDO::PARAM_STR);

		$r = $stmtx->execute();
	}
	catch(PDOException $exception){ 
       echo $exception->getMessage(); 
       die();
    } 
}

echo $id_ordem_serv;


?>
