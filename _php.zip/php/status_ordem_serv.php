﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


function saveOS($conn,$status,$id_os,$iniciado = false) {

	$campo = '';
	$status_entregador = 'EM TRANSITO';
	$nu_total = 0;

	if($iniciado){
		$campo = 'dt_inicio = now(),';
	}
	else {
		if($status == 'FINALIZADO' || $status == 'CANCELADO'){

			$trajeto = $conn->prepare("SELECT SUM(TIMESTAMPDIFF(MINUTE,dt_inicio_pausa,dt_fim_pausa)) as dif_min FROM trajeto where dt_inicio_pausa IS NOT NULL AND dt_fim_pausa IS NOT NULL AND id_ordem_serv = :id_ordem_serv");

			$trajeto->bindParam(':id_ordem_serv', $id_os, PDO::PARAM_INT);
			$trajeto->execute();
			$res = $trajeto->fetch();

			if(!empty($res['dif_min'])){
				$nu_total = $res['dif_min'];
			}
			else{
				$stmt_os = $conn->prepare("SELECT id_tarifa FROM ordem_serv WHERE id_ordem_serv = :id_ordem_serv");
				$stmt_os->bindParam(':id_ordem_serv', $id_os, PDO::PARAM_INT);
				$stmt_os->execute();
				$res = $stmt_os->fetch();

				if($res['id_tarifa'] != 3)
					$campo .= 'st_pagamento = "RECEBIDO", ';
			}

			$campo = 'dt_termino = now(),';
			$status_entregador = 'BASE';
		}
	}

	$stmt = $conn->prepare("UPDATE ordem_serv SET ".$campo." dt_ult_mov = now(), nu_total_min_espera = :nu_total, st_os = :st_os WHERE id_ordem_serv = :id_ordem_serv");

	$stmt->bindParam(':st_os', $status, PDO::PARAM_STR); 
	$stmt->bindParam(':id_ordem_serv', $id_os, PDO::PARAM_INT); 
	$stmt->bindParam(':nu_total', $nu_total, PDO::PARAM_INT); 

	if($stmt->execute()){
		$entregador = getEntregadorOS($conn,$id_os);
		return !empty($entregador) ? saveStatusEntregador($conn,$entregador['id_entregador'],$status_entregador) : false;
	}
}

function saveStatusEntregador($conn,$id_entregador,$status){

	$stmt = $conn->prepare("UPDATE entregador SET st_entregador = :st_entregador WHERE id_entregador = :id_entregador");

	$stmt->bindParam(':st_entregador', $status, PDO::PARAM_STR); 
	$stmt->bindParam(':id_entregador', $id_entregador, PDO::PARAM_INT); 

	return $stmt->execute();
}

// SALVA PRIMEIRO TRAJETO!!!

if($_POST['status'] == 'despausar_os'){

	$origem  = getOrigem($conn,$_POST['id']);
	$destino = getDestino($conn,$_POST['id']);

	$return_distancia = !empty($origem) ? consultaGoogle($origem,$destino['ds_endereco']) : '';
	

	$res = saveOS($conn,'INICIADO',$_POST['id']);

	if(!$res)
		die('Erro ao salvar a OS');

	$entregador = getEntregadorOS($conn,$_POST['id']);

	$res = saveTrajeto($conn,$destino,$entregador['id_entregador'],$return_distancia);
	
	if(!$res)
		die('Erro ao salvar o Trajeto');

}
else if($_POST['status'] == 'finalizar_os'){
	$res = saveOS($conn,'FINALIZADO',$_POST['id']);
}
else if($_POST['status'] == 'cancelar_os'){
	$res = saveOS($conn,'CANCELADO',$_POST['id']);

	$stmt = $conn->prepare("UPDATE trajeto SET st_ordem_serv_item = 'CANCELADO' WHERE id_trajeto > 0 AND id_ordem_serv = :id_ordem_serv");
	$stmt->bindParam(':id_ordem_serv', $_POST['id'], PDO::PARAM_INT); 
	$stmt->execute();
}
else if($_POST['status'] == 'pagar_os'){

	$stmt = $conn->prepare("UPDATE ordem_serv SET id_tipo_pagto = :id_tipo_pagto, vl_troco = :vl_troco, observacao = :observacao, dt_ult_mov = now(), st_pagamento = 'RECEBIDO', vlr_os_final = :vlr_os_final WHERE id_ordem_serv = :id_ordem_serv");

	$field = [];
	foreach ($_POST['data'] as $key => $value) {
		$field[$value['name']] = $value['value'];
	}		

	$stmt->bindParam(':id_tipo_pagto', $field['id_tipo_pagto'], PDO::PARAM_INT); 
	$stmt->bindParam(':vl_troco', $field['vl_troco'], PDO::PARAM_INT); 
	$stmt->bindParam(':observacao', $field['observacao'], PDO::PARAM_STR); 
	$stmt->bindParam(':vlr_os_final', $field['vlr_os_final'], PDO::PARAM_INT); 
	$stmt->bindParam(':id_ordem_serv', $_POST['id'], PDO::PARAM_INT); 

	$stmt->execute();

}
else {
	if(saveOS($conn,'INICIADO',$_POST['id'],true)){

		$res = getTrajeto($conn,$_POST['id']);

		$entregador = getEntregadorOS($conn,$_POST['id']);

		$stmt_os = $conn->prepare("UPDATE trajeto SET dt_inicio = now(), id_entregador = :id_entregador WHERE id_trajeto = :id_trajeto");
		$stmt_os->bindParam(':id_trajeto', $res['id_trajeto'], PDO::PARAM_INT);	
		$stmt_os->bindParam(':id_entregador', $entregador['id_entregador'], PDO::PARAM_INT);	

		$res = $stmt_os->execute();
	}
}


if(!$res) {
	echo 'Erro ao salvar a Ordem de Serviço';
	die();
}

function getEntregadorOS($conn,$id_ordem_serv) {
	
	$os = $conn->prepare('SELECT id_entregador FROM ordem_serv WHERE id_ordem_serv = :id_ordem_serv');
	$os->bindParam(':id_ordem_serv', $id_ordem_serv, PDO::PARAM_INT);
	$os->execute();
	
	return $os->fetch();	
}

function getTrajeto($conn,$id_ordem_serv,$ultimo = false) {

	$where = $ultimo ? 'id_ordem_serv = :id_ordem_serv AND dt_inicio IS NOT NULL ORDER BY cp_ordem DESC LIMIT 1' : 'id_ordem_serv = :id_ordem_serv AND cp_ordem = 0';
	
	$trajeto = $conn->prepare('SELECT id_trajeto FROM trajeto WHERE '.$where);
	$trajeto->bindParam(':id_ordem_serv', $id_ordem_serv, PDO::PARAM_INT);
	$trajeto->execute();
	
	return $trajeto->fetch();
}

function getDestino($conn,$id_ordem_serv) {

	$ultimo_trajeto = $conn->prepare('SELECT ds_endereco,nu_duracao,id_trajeto FROM trajeto WHERE id_ordem_serv = :id_ordem_serv AND dt_inicio IS NOT NULL ORDER BY cp_ordem DESC LIMIT 1');
	$ultimo_trajeto->bindParam(':id_ordem_serv', $_POST['id'], PDO::PARAM_INT);
	$ultimo_trajeto->execute();

	return  $ultimo_trajeto->fetch();
}


function getOrigem($conn,$id_ordem_serv) {

	$os = $conn->prepare('SELECT ordem_serv.id_entregador,st_entregador,id_trajeto_atual FROM ordem_serv INNER JOIN entregador ON ordem_serv.id_entregador = entregador.id_entregador WHERE id_ordem_serv = :id_ordem_serv');
	$os->bindParam(':id_ordem_serv', $id_ordem_serv, PDO::PARAM_INT);
	$os->execute();

	$entregador = $os->fetch();

	$local = '';
	
	if($entregador['st_entregador'] == 'EM TRANSITO'){

		if($entregador['id_trajeto'] != 0){
			$tj = $conn->prepare('SELECT ds_endereco FROM trajeto WHERE id_trajeto = :id_trajeto');
			$tj->bindParam(':id_trajeto', $entregador['id_trajeto'], PDO::PARAM_INT);
		}
		else{
			$tj = $conn->prepare('SELECT ds_endereco FROM trajeto WHERE id_entregador = :id_entregador ORDER BY dt_entrega DESC LIMIT 1');
			$tj->bindParam(':id_entregador', $entregador['id_entregador'], PDO::PARAM_INT);
		}
	
		$tj->execute();
		$trajeto = $tj->fetch();

		$local = $trajeto['ds_endereco'];
	}

	return $local;
}

function consultaGoogle($origem,$destino){

	$cp_result=urlencode($origem).'&destinations='.urlencode($destino);

	$url='https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$cp_result.'&key=AIzaSyCoa2nY5o8Hs5HlRleViH7kFV9qlkRDTZE';

	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_HEADER, false);
	$data = curl_exec($curl);
	curl_close($curl);
	if($data === FALSE) {
	    die(curl_error($ch));
	}
	else {
	    $r = json_decode($data);
	    return $r->rows[0]->elements[0]->duration->value;
	}
}

function saveTrajeto($conn,$destino,$entregador,$dif_duracao){

	$dif = $destino['nu_duracao'] - $dif_duracao;

	$stmt = $conn->prepare("UPDATE trajeto SET dif_duracao = :dif_duracao, dt_ult_mov = now(), dt_fim_pausa = now(), id_entregador = :id_entregador WHERE id_trajeto = :id_trajeto");
	
	$stmt->bindParam(':dif_duracao', $dif, PDO::PARAM_INT); 
	$stmt->bindParam(':id_trajeto', $destino['id_trajeto'], PDO::PARAM_INT); 
	$stmt->bindParam(':id_entregador', $entregador, PDO::PARAM_INT);

	return $stmt->execute();
}

?>
