﻿<?php

$id = $_POST['cp_id'];
$user = $_POST['cp_user'];

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("UPDATE roteiro SET id_entregador=? WHERE id_ordem_serv=?");	  
$stmt->execute(array($user,$id));
$result = $stmt->fetch();

echo $result;
?>