﻿<?php

$id = $_POST['id'];
$id_tarifa = $_POST['tarifa'];

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

/*
$smtp_os = $conn->prepare("SELECT * FROM ordem_serv WHERE id_ordem_serv = ?");
$smtp_os->execute(array($id));
$result_os = $smtp_os->fetch();
*/


// TARIFAS 
$smtp_tt = $conn->prepare("SELECT * FROM tarifa_item WHERE id_tarifa = ?");
$smtp_tt->execute(array($id_tarifa));
$tarifas = $smtp_tt->fetchAll();

// TOTAL ROTEIRO
$stmt = $conn->prepare("SELECT count(id_ordem_serv) as qtd_roteiros, sum(nu_distancia) as tot_distancia, sum(nu_duracao) as tot_duracao  FROM roteiro WHERE id_ordem_serv = ?");
$stmt->execute(array($id));
$roteiros = $stmt->fetch();


$roteiros['vlr_os_previsto'] = 0;

// TARIFA 4

// TOTAL ROTEIRO
foreach ($tarifas as $tarifa) {
	
	// 1 == KM | MIN

	if($tarifa['id_tipo_tarifa'] == 1) {
		// 56
		$qtd_total = $roteiros['tot_distancia'];
	}
	elseif ($tarifa['id_tipo_tarifa'] == 3) {
		$qtd_total = $roteiros['tot_duracao'];
	}
	elseif ($tarifa['id_tipo_tarifa'] == 4) {
		$roteiros['vlr_os_previsto'] += intval($roteiros['qtd_roteiros'])*floatval($tarifa['vlr_tipo_tarifa']);
		continue;
	}
	else{
		$roteiros['vlr_os_previsto'] += intval($tarifa['qtd_roteiros']);
		continue;
	}

	$valor_total = compararMinMax($qtd_total,$tarifa['qtd_faixa_tarifa_min'],$tarifa['qtd_faixa_tarifa_max']);
	
	// 60 * 4 = 240
	$qtd_total   = floatval($valor_total)*floatval($tarifa['vlr_tipo_tarifa']);

	
	$valor_total = compararMinMax($qtd_total,$tarifa['vlr_tarifa_min'],$tarifa['vlr_tarifa_max']);
	
	
	$roteiros['vlr_os_previsto'] += $valor_total;
}

function compararMinMax($valor,$min,$max){

	if(intval($valor) < intval($min))
		return $min;
	elseif (intval($valor) > intval($max))
		return $max;
	else
		return $valor;
}

echo json_encode($roteiros);

?>