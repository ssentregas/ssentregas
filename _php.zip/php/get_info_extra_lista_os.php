﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$where = !empty($_POST['criteria']) ? ' WHERE '.$_POST['criteria'] : '';

var_dump("SELECT COUNT(vlr_os_final) as vlr_os_final FROM ordem_serv".$where);

$os = $conn->prepare("SELECT COUNT(vlr_os_final) as vlr_os_final FROM ordem_serv".$where);
$os->execute();
$result = $os->fetch();



echo json_encode($result);

?>
