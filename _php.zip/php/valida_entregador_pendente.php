﻿<?php

include('settings.php');  
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT COUNT(id_ordem_serv) as qtd FROM ordem_serv WHERE id_entregador = :id_entregador AND st_os = 'FINALIZADO' AND st_pagamento = 'AGUARDANDO' AND id_forma_pagto = 3");
$stmt->bindParam(':id_entregador', $_POST['id'], PDO::PARAM_INT); 
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

if($result[0]->qtd > 0){
  echo 'Este entregador tem '.$result[0]->qtd.' O.S. FINALIZADA(S) que ainda não deu baixa no PAGAMENTO.';
}