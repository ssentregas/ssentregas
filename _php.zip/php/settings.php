<?php
define("DATABASE_HOST","jjcs1db0.cvpeqnywkfxy.sa-east-1.rds.amazonaws.com");
define("DATABASE_NAME","ssentregas");
define("DATABASE_USER","DB1_MasterUser");
define("DATABASE_PASS","BD1Master16");
?>
