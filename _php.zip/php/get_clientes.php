﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$term = '%'.$_GET['q'].'%';

$stmt = $conn->prepare("SELECT id_cliente as id, nm_cliente as text FROM cliente WHERE nm_cliente LIKE :nm_cliente OR cpf_cnpj LIKE :cpf_cnpj");

$stmt->bindParam(':nm_cliente', $term, PDO::PARAM_STR); 
$stmt->bindParam(':cpf_cnpj', $term, PDO::PARAM_STR); 

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

echo json_encode($result);

?>
