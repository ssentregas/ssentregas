﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT cp_completo as text,id_local_cliente as value FROM local_cliente WHERE id_local_cliente = :id_local_cliente");

$stmt->bindParam(':id_local_cliente', $_GET['id'], PDO::PARAM_INT); 

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

echo json_encode($result);

?>
