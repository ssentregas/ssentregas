﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

session_start();
$stmt = $conn->prepare("SELECT count(id_entregador_msg) FROM entregador_msg WHERE dt_inclusao > ".$_SESSION['ultima_atualizacao']);

$stmt->execute();

$res = $stmt->fetch();

echo $res[0];

?>
