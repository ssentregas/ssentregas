﻿
<?php
include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT cliente.id_forma_pagto as id, forma_pagto.descricao as text FROM cliente INNER JOIN forma_pagto ON forma_pagto.id_forma_pagto = cliente.id_forma_pagto WHERE id_cliente = :id_cliente");
$stmt->bindParam(':id_cliente', $_POST['id'], PDO::PARAM_INT); 
$stmt->execute();
$cliente = $stmt->fetchAll(PDO::FETCH_CLASS);

$cliente = !empty($cliente[0]) ? $cliente[0]->id : 3;

$stmt = $conn->prepare("SELECT * FROM cliente WHERE id_cliente = :id_cliente");
$stmt->bindParam(':id_cliente', $_POST['id'], PDO::PARAM_INT); 
$stmt->execute();
$endereco = $stmt->fetchAll(PDO::FETCH_CLASS);

$end = $endereco[0]->endereco.', nº '.$endereco[0]->numero.', '.$endereco[0]->complemento.' - '.$endereco[0]->bairro.' / '.$endereco[0]->localidade;

$stmt = $conn->prepare("SELECT id_forma_pagto as id, descricao as text FROM forma_pagto");
$stmt->execute();
$options = $stmt->fetchAll(PDO::FETCH_CLASS);


echo json_encode(['cliente'=>$cliente,'options'=>$options,'endereco'=>$end]);

?>
