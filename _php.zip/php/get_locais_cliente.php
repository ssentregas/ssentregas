﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT cp_completo as text,id_local_cliente as value FROM local_cliente WHERE cp_completo LIKE :cp_completo AND id_cliente = :id_cliente");

$term = "%".$_GET['term']."%";
$stmt->bindParam(':id_cliente', $_GET['id_cliente'], PDO::PARAM_INT); 
$stmt->bindParam(':cp_completo', $term, PDO::PARAM_STR); 

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

echo json_encode($result);

?>
