﻿<?php

$id = $_POST['id'];

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT id_cliente FROM ordem_serv where id_ordem_serv = ?");
$stmt->execute(array($id));
$result = $stmt->fetch();

echo $result['id_cliente'];

?>