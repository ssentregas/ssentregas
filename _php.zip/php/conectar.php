<?php

include('settings.php');
require 'zebra/Zebra_Database.php';

//	header('Content-Type: text/html; charset=utf-8');

	$conn = new Zebra_Database();
	$conn->connect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS, DATABASE_NAME);
	$conn->query( "SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'" );
?>
