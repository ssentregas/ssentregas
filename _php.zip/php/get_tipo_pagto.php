﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT id_tipo_pagto as id ,ds_tipo_pagto as value FROM tipo_pagto");
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

echo json_encode($result);

?>
