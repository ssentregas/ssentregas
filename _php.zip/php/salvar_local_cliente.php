﻿<?php

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("INSERT INTO local_cliente (id_cliente,cep_local_cliente,endereco_local_cliente,numero_local_cliente,complemento_local_cliente,bairro_local_cliente,cidade_local_cliente,uf_local_cliente) VALUES (:id_cliente,:cep,:endereco,:numero,:complemento,:bairro,:cidade,:uf)");	  

$stmt->bindParam(':id_cliente', $_POST['id_cliente'], PDO::PARAM_INT); 
$stmt->bindParam(':cep', $_POST['cep_local_cliente_edit'], PDO::PARAM_STR); 
$stmt->bindParam(':endereco', $_POST['endereco_local_cliente_edit'], PDO::PARAM_STR); 
$stmt->bindParam(':numero', $_POST['numero_local_cliente_edit'], PDO::PARAM_STR); 
$stmt->bindParam(':complemento', $_POST['complemento_local_cliente_edit'], PDO::PARAM_STR); 
$stmt->bindParam(':bairro', $_POST['bairro_local_cliente_edit'], PDO::PARAM_STR); 
$stmt->bindParam(':cidade', $_POST['cidade_local_cliente_edit'], PDO::PARAM_STR); 
$stmt->bindParam(':uf', $_POST['uf_local_cliente_edit'], PDO::PARAM_STR); 

echo $stmt->execute();

?>
