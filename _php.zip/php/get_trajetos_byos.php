﻿<?php
include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$os = $conn->prepare("SELECT st_os,nu_total_min_espera,st_pagamento,nu_ordem_serv,id_tarifa,id_forma_pagto,vlr_os_final,vl_troco,id_tipo_pagto,coalesce(DATE_FORMAT(dt_inicio,'%d/%m/%Y %H:%i'),'') as dt_inicio FROM ordem_serv WHERE id_ordem_serv = :id_ordem_serv");
$os->bindParam(':id_ordem_serv', $_POST['id'], PDO::PARAM_INT); 
$os->execute();
$st_os = $os->fetch();

$campos = array();
$campos[] = 'trajeto.id_trajeto';
$campos[] = 'trajeto.ds_endereco';
$campos[] = 'trajeto.ds_complemento';
$campos[] = 'trajeto.ds_observacao';
$campos[] = "coalesce(DATE_FORMAT(trajeto.dt_inicio_pausa,'%H:%i'),'--:--') as dt_inicio_pausa";
$campos[] = "coalesce(DATE_FORMAT(trajeto.dt_fim_pausa,'%H:%i'),'--:--') as dt_fim_pausa";
$campos[] = "coalesce(DATE_FORMAT(trajeto.dt_entrega,'%H:%i'),'--:--') as dt_entrega";
$campos[] = "coalesce(DATE_FORMAT(trajeto.dt_inicio,'%H:%i'),'--:--') as dt_inicio";
$campos[] = "coalesce(DATE_FORMAT(trajeto.dt_entrega_prevista,'%H:%i'),'--:--') as dt_entrega_prevista";
$campos[] = 'trajeto.st_ordem_serv_item';
$campos[] = 'nm_entregador';


$stmt = $conn->prepare("SELECT ".implode($campos, ',')." FROM trajeto LEFT JOIN entregador ON entregador.id_entregador = trajeto.id_entregador WHERE id_ordem_serv = :id_ordem_serv ORDER BY trajeto.cp_ordem");

$stmt->bindParam(':id_ordem_serv', $_POST['id'], PDO::PARAM_INT); 

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_CLASS);

echo json_encode(array(
	'trajetos'      => $result,
	'vlr_os_final'  => intVal($st_os['vlr_os_final']),
	'vlr_troco'     => intVal($st_os['vl_troco']),
	'st_os'         => $st_os['st_os'],
	'st_pagto'      => $st_os['st_pagamento'],
	'id_forma_pagto'=> $st_os['id_forma_pagto'],
	'id_tipo_pagto' => $st_os['id_tipo_pagto'],
	'id_tarifa'     => $st_os['id_tarifa'],
	'nu_ordem_serv' => $st_os['nu_ordem_serv'],
	'dif_espera'    => intVal($st_os['nu_total_min_espera']),
	'dt_inicio'		=> $st_os['dt_inicio']
));

?>
