﻿<script type="text/javascript">
	if($('#status_motoboy').length > 0){

$('h1').parents('.row').prepend($('#status_motoboy').show());

setInterval(function(){$.ajax({
   url: 'php/get_dashboard_motoboys.php',
   success: function(e){
      var motoboys = $.parseJSON(e);
      $('#em_transito tbody,#na_base tbody').html('');
      
      $.each(motoboys['em_transito'],function(i,v){ 
         
         tr  = "<td>"+v['nm_entregador']+"</td>";
         tr += "<td>"+v['qt_os_iniciada']+"</td>";
         tr += "<td>"+v['qt_os_finalizada']+"</td>";
         tr += "<td>"+v['qt_os_pausada']+"</td>";
         tr += "<td>"+v['ponto']+"</td>";
         tr += "<td>"+v['previsao_retorno']+"</td>";
         
         $('#em_transito tbody').prepend("<tr>"+tr+"</tr>");
      });
      
      $.each(motoboys['na_base'],function(i,v){ 
         tr  = "<td>"+v['nm_entregador']+"</td>";
         tr += "<td>"+v['qt_os_iniciada']+"</td>";
         tr += "<td>"+v['qt_os_finalizada']+"</td>";
         tr += "<td>"+v['qt_os_pausada']+"</td>";
         $('#na_base tbody').prepend("<tr>"+tr+"</tr>");
      });
      
   }
})},3000);

$('#ini_fin_trajeto').click(function(){
   $.ajax({
      url: 'php/status_trajeto_mala.php',
      data: $('#form_trajeto').serializeArray(),
      type: 'POST',
      success:function(e){
      alert('Salvo com sucesso');
      window.location.href = '';
      //carregaTrajetos($('#id_ordem_serv').val());      
      }
   });
});

$('#salvar_trajeto').click(function(){
   $.ajax({
      url: 'php/status_trajeto.php',
      data: $('#form_trajeto').serializeArray(),
      type: 'POST',
      success:function(e){
        alert('Trajeto salvo com sucesso');
        window.location.href = '';
//      carregaTrajetos($('#id_ordem_serv').val());      
      }
   });
});

carregaTipoPagamento = function(){
   $('#id_tipo_pagto').html('');
   $.ajax({
      url: 'php/get_tipo_pagto.php',
      type: 'POST',
      success:function(e){
         var data = $.parseJSON(e);
         $.each(data,function(i,v){
            $('#id_tipo_pagto').append("<option value='"+v['id']+"'>"+v['value']+"</option>");
         });
      }
   });
}


carregaEntregadores = function(){
   $('#id_entregador select').html('');
   $.ajax({
      url: 'php/get_entregadores.php',
      type: 'POST',
      success:function(e){
         var data = $.parseJSON(e);
         $.each(data,function(i,v){
            $('#id_entregador select').append("<option value='"+v['id_entregador']+"'>"+v['nm_entregador']+"</option>");
         });
      }
   });
}


carregaTrajetos = function(id){
   
    $('#iniciar_os,#salvar_trajeto,#despausar_os,#finalizar_os,#form_trajeto,#form_pagamento_os,#pagar_os').hide();
    $('#trajetos_os tbody').html('');

    $.ajax({
        url: 'php/get_trajetos_byos.php',
        data: {id: id},
        type: 'POST',
        success:function(e){

            var data = $.parseJSON(e);
            var st_os = data['st_os'];
         
         $('#trajetos .modal-title').text('N. da O.S #'+data['nu_ordem_serv']);
         
         if(data['id_tarifa'] == 3){
            $('tr#mala_direta').hide();
            $('#id_tarifa').val('');
            $('tr#ponto_a_ponto').show();
         }
         else{
            $('tr#ponto_a_ponto').hide();
            $('#id_tarifa').val(1);
            $('#prev_espera,#inicio_espera,#tp_trajeto').hide();
            $('tr#mala_direta').show();
         }

         $.each(data['trajetos'],function(index,value){

            $tr = '<tr>';

            $tr += '<td>'+value['ds_endereco']+'</td>';
            $tr += '<td>'+value['ds_complemento']+'</td>';
            
            if(data['id_tarifa'] == 3){
                $tr += '<td>'+value['dt_inicio_pausa']+'/'+value['dt_fim_pausa']+'</td>';
                $tr += '<td>'+value['dt_entrega_prevista']+'/'+value['dt_entrega']+'</td>';                    
            }
            else{
                $tr += '<td>'+value['nm_entregador']+'</td>';   
                $tr += '<td>'+value['dt_inicio']+'/'+value['dt_entrega']+'</td>';                    
            }
            
            $tr += '<td>'+value['ds_observacao']+'</td>';
                        
            $tr += '<td>'+value['nm_entregador']+'</td>';

            $tr += '<td>';
            
            if(value['dt_entrega'] == '--:--' && ((st_os != 'AGUARDANDO' && st_os != 'PAUSADA') || data['id_tarifa'] != 3)) {
               $tr += '<i data-inicio="'+(value['dt_inicio'] == '--:--')+'" data-id="'+value['id_trajeto']+'" class="icon-edit"></i>';
            }
            $tr += '</td>';

            $tr += '</tr>';

            $('#trajetos_os tbody').append($tr);
         });
         
         $('#ini_fin_trajeto').hide();
         
         if(st_os == 'AGUARDANDO' && data['id_tarifa'] == 3){
            $('#iniciar_os').show();
         } else if(st_os == 'PAUSADA' && data['id_tarifa'] == 3){
            $('#despausar_os').show();
         } else if(st_os == 'INICIADO') {
            if($('#trajetos_os tbody .icon-edit').length == 0){
               $('#finalizar_os').show();
            }
         } else if(st_os == 'FINALIZADO' && data['id_forma_pagto'] == 3) {
            carregaTipoPagamento();
            $('#form_pagamento_os,#pagar_os').show();
         }
      }
   });
}
$('#iniciar_os,#despausar_os,#finalizar_os').click(function(){
   atualiza = true;
   if($(this).attr('id') == 'despausar_os'){
      atualiza = false;
   }
   $.ajax({
      url: 'php/status_ordem_serv.php',
      data: {id: $('#id_ordem_serv').val(),status: $(this).attr('id')},
      type: 'POST',
      success:function(e){
      if(atualiza){
      window.location.href = '';
      }else{
      carregaTrajetos($('#id_ordem_serv').val());
      }
      }
   });
});

$('#ordem_servGrid tbody td').click(function(){
   
   if($(this).hasClass('operation-column'))
     return false;
   
   $('#trajetos_os tbody').html('');
   
   var id = $(this).parents('tr').find('td[data-column-name="id_ordem_serv"]').text();
   
   $('#id_ordem_serv').val(id);
   carregaTrajetos(id);
   carregaEntregadores();
   
   $('#trajetos').modal('show');
});

$(document).on('click','#trajetos_os .icon-edit',function(){
        
   if($('#id_tarifa').val() == ''){
     $('#st_trajeto').show();
     $('#st_trajeto select').change();
     $('#salvar_trajeto').show();
   }
   else{
     
     $('#inicio_espera,#tp_trajeto,#prev_espera,#recebedor,#st_trajeto').hide();
     
     if($(this).attr('data-inicio') == 'true'){
        $('#ini_fin_trajeto').text('INICAR TRAJETO');
     }
     else{
        $('#recebedor').show();
        $('#ini_fin_trajeto').text('FINALIZAR TRAJETO');
     }
     $('#ini_fin_trajeto').show(); 
   }

   $('#trajetos .modal-footer,#form_trajeto').show();

   $('#trajetos_os tbody tr').hide();
   $('#id_trajeto').val($(this).attr('data-id'));
   $(this).parents('tr').show();
});

$('.btn_trajeto').click(function(){
   $('#trajetos_os tbody tr').show();
   $('#form_trajeto,#trajetos .modal-footer').hide();
});

$('#st_trajeto select').change(function(){       
  $('#inicio_espera,#tp_trajeto,#prev_espera,#recebedor').hide();
  
  if($(this).val() == '2')
    $('#inicio_espera,#prev_espera').show();
  else
    $('#tp_trajeto').show();
});

$('#tp_trajeto select').change(function(){
  $('#recebedor').hide();
  if($(this).val() =='2'){
     $('#recebedor').show();
  }
});
}
</script>