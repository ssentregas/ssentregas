﻿<?php
include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt_trajeto = $conn->prepare("SELECT trajeto.id_ordem_serv,id_trajeto,cp_ordem,ordem_serv.id_entregador FROM trajeto INNER JOIN ordem_serv ON ordem_serv.id_ordem_serv = trajeto.id_ordem_serv WHERE id_trajeto = :id_trajeto AND trajeto.id_ordem_serv = :id_ordem_serv");
$stmt_trajeto->bindParam(':id_ordem_serv', $_POST['id_ordem_serv'], PDO::PARAM_INT);
$stmt_trajeto->bindParam(':id_trajeto', $_POST['id_trajeto'], PDO::PARAM_INT);
$stmt_trajeto->execute();

$trajeto = $stmt_trajeto->fetch();

if(empty($trajeto)){
	echo 'Trajeto não foi encontrado';
	die();
}

$campos = "dt_ult_mov = now()";

$tp_trajeto = array('COLETA','ENTREGA');

if($_POST['st_trajeto'] == '2') {

	$campos .= ",st_os = 'PAUSADA'";

	// SALVA HORA DA PAUSA E PREVISÃO DO TEMPO DA PAUSA E PAUSA ORDEM DE SERVIÇO!!!

	$stmt = $conn->prepare("UPDATE trajeto SET dt_inicio_pausa = :dt_inicio_pausa, prev_pausa = :prev_pausa, ds_observacao = :ds_observacao, id_entregador = :id_entregador  WHERE id_trajeto = :id_trajeto");
	
	$stmt->bindParam(':prev_pausa', $_POST['prev_espera'], PDO::PARAM_INT); 

    date_default_timezone_set('America/Sao_Paulo');
	$dt_inicio_pausa = !empty($_POST['hr_inicio_pausa']) ? date('Y-m-d').' '.$_POST['hr_inicio_pausa'] : date('Y-m-d H:i:s');

	$stmt->bindParam(':dt_inicio_pausa', $dt_inicio_pausa, PDO::PARAM_STR);
	$stmt->bindParam(':ds_observacao', $_POST['observacao'], PDO::PARAM_STR); 
	$stmt->bindParam(':id_trajeto', $trajeto['id_trajeto'], PDO::PARAM_INT);
	$stmt->bindParam(':id_entregador', $_POST['id_entregador'], PDO::PARAM_INT);
	$res = $stmt->execute();
	
}
else{

	$stmt = $conn->prepare("UPDATE trajeto SET tp_trajeto = :tp_trajeto, nm_contato = :nm_contato, ds_observacao = :ds_observacao, st_ordem_serv_item = 'FINALIZADO', dt_entrega = now(), id_entregador = :id_entregador WHERE id_trajeto = :id_trajeto");

	// FINALIZA TRAJETO!!
	$stmt->bindParam(':tp_trajeto', $tp_trajeto[$_POST['tp_trajeto']-1], PDO::PARAM_STR);
	$stmt->bindParam(':nm_contato', $_POST['recebedor'], PDO::PARAM_STR);
	$stmt->bindParam(':ds_observacao', $_POST['observacao'], PDO::PARAM_STR); 
	$stmt->bindParam(':id_trajeto', $trajeto['id_trajeto'], PDO::PARAM_INT);
	$stmt->bindParam(':id_entregador', $_POST['id_entregador'], PDO::PARAM_INT);
	$res = $stmt->execute();


	if($res){
		$res = iniciaProximoTrajeto($conn,$trajeto['id_ordem_serv'],$trajeto['cp_ordem'],$_POST['id_entregador']);
	}
}

if(!$res) {
	echo 'Erro ao salvar o trajeto';
	die();
}

// SALVA ORDEM DE SERVIÇO!!!

$stmt_os = $conn->prepare("UPDATE ordem_serv SET ".$campos." WHERE id_ordem_serv = :id_ordem_serv");
$stmt_os->bindParam(':id_ordem_serv', $trajeto['id_ordem_serv'], PDO::PARAM_INT);
$res = $stmt_os->execute();

if(!$res) {
	echo 'Erro ao salvar a Ordem de Serviço';
	die();
}


function iniciaProximoTrajeto($conn,$id_ordem_serv,$cp_ordem,$id_entregador){

	$cp_ordem = $cp_ordem + 1;


	$stmt = $conn->prepare("SELECT id_trajeto FROM trajeto WHERE cp_ordem = :cp_ordem AND id_ordem_serv = :id_ordem_serv");
	$stmt->bindParam(':cp_ordem', $cp_ordem, PDO::PARAM_INT);
	$stmt->bindParam(':id_ordem_serv', $id_ordem_serv, PDO::PARAM_INT);
	$stmt->execute();

	$tj = $stmt->fetch();
	if(empty($tj)){
		return iniciaRetornoOS($conn,$id_ordem_serv);
	}
	

	$trajeto = $conn->prepare("UPDATE trajeto SET dt_inicio = now(),id_entregador = :id_entregador WHERE id_trajeto = :id_trajeto");
	$trajeto->bindParam(':id_trajeto', $tj['id_trajeto'], PDO::PARAM_INT);
	$trajeto->bindParam(':id_entregador', $id_entregador, PDO::PARAM_INT);
	
	return $trajeto->execute();

}

function iniciaRetornoOS($conn,$id_ordem_serv){
	$stmt = $conn->prepare("UPDATE ordem_serv SET dt_inicio_retorno = now() WHERE id_ordem_serv = :id_ordem_serv");
	$stmt->bindParam(':id_ordem_serv', $id_ordem_serv, PDO::PARAM_INT);
	
	return $stmt->execute();
}

?>
