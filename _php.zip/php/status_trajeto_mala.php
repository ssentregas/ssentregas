﻿<?php
include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt_trajeto = $conn->prepare("SELECT id_ordem_serv,id_trajeto,dt_inicio FROM trajeto WHERE id_trajeto = :id_trajeto AND id_ordem_serv = :id_ordem_serv");
$stmt_trajeto->bindParam(':id_trajeto', $_POST['id_trajeto'], PDO::PARAM_INT);
$stmt_trajeto->bindParam(':id_ordem_serv', $_POST['id_ordem_serv'], PDO::PARAM_INT);
$stmt_trajeto->execute();

$trajeto = $stmt_trajeto->fetch();

if(empty($trajeto)){
	echo 'Trajeto não foi encontrado';
	die();
}

if(empty($trajeto['dt_inicio'])){
	$stmt = $conn->prepare("UPDATE trajeto SET st_ordem_serv_item = 'INICIADO',dt_inicio = now(), ds_observacao = :ds_observacao, id_entregador = :id_entregador, dt_ult_mov = now() WHERE id_trajeto = :id_trajeto");
	$stmt->bindParam(':id_entregador', $_POST['id_entregador'], PDO::PARAM_INT);
}
else{
	$stmt = $conn->prepare("UPDATE trajeto SET st_ordem_serv_item = 'FINALIZADO',dt_entrega = now(), ds_observacao = :ds_observacao, dt_ult_mov = now(), nm_contato = :recebedor WHERE id_trajeto = :id_trajeto");
	$stmt->bindParam(':recebedor', $_POST['recebedor'], PDO::PARAM_STR);
}

$stmt->bindParam(':ds_observacao', $_POST['observacao'], PDO::PARAM_STR);
$stmt->bindParam(':id_trajeto', $trajeto['id_trajeto'], PDO::PARAM_INT);
$res = $stmt->execute();


if(!$res) {
	echo 'Erro ao salvar o trajeto';
	die();
}

$stmt = $conn->prepare("UPDATE ordem_serv SET st_os = 'INICIADO', dt_ult_mov = now() WHERE id_ordem_serv = :id_ordem_serv");
$stmt->bindParam(':id_ordem_serv', $trajeto['id_ordem_serv'], PDO::PARAM_INT);
$res = $stmt->execute();


if(!$res) {
	echo 'Erro ao salvar a Ordem de serviço';
	die();
}
?>
