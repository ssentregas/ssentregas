﻿<?php

$id = $_POST['id'];

include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);

$stmt = $conn->prepare("SELECT id_forma_pagto FROM cliente where id_cliente = ?");
$stmt->execute(array($id));
$result = $stmt->fetch();

echo $result['id_forma_pagto'];

?>