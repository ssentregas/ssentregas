﻿<?php
include('settings.php');	
$conn = new PDO('mysql:host='.DATABASE_HOST.';dbname='.DATABASE_NAME.';charset=utf8',DATABASE_USER,DATABASE_PASS);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


$campo = array(
	'iniciar' 		 => 'hr_fim_expediente = NULL, hr_inicio_almoco = NULL, hr_fim_almoco = NULL, hr_inicio_expediente',
	'fim_expediente' => 'hr_fim_expediente',
	'almocar'        => 'hr_inicio_almoco',
	'fim_almoco' 	 => 'hr_fim_almoco',
);

if(isset($_GET['status'])) {
	$stmt = $conn->prepare("UPDATE entregador SET ".$campo[$_GET['status']]." = now() WHERE id_entregador = :id_entregador");
	$stmt->bindParam(':id_entregador', $_GET['id'], PDO::PARAM_INT); 
	$stmt->execute();

	header('location: ../entregador.php');
}

?>
