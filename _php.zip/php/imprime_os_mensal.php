<?php

$id = $_GET['id'];

require 'conectar.php';

$conn->query("select now() as dt");
$hoje = $conn->fetch_assoc();

$conn->query("
SELECT ordem_serv.dt_termino, 
	   ordem_serv.nu_ordem_serv,
       cliente.nm_cliente,
       entregador.nm_fantasia,
       ordem_serv.st_pagamento,
       ordem_serv.vlr_os_previsto,
       ordem_serv.vlr_os_final
  FROM ordem_serv ordem_serv
	   INNER JOIN entregador
           ON (ordem_serv.id_entregador = entregador.id_entregador)
       INNER JOIN ssentregas.cliente cliente
          ON (ordem_serv.id_cliente = cliente.id_cliente)
WHERE DATE_FORMAT(dt_termino, '%Y%m')=?
ORDER BY ordem_serv.dt_termino ASC;
",array($id));
$entregas = $conn->fetch_assoc_all();

?>


<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
<head>

	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="description" content="entrega">
	<meta name="varios" content="">

	<title>Lista Trajeto Mensal</title>

	<!-- Mobile Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Favicons -->
	<link rel="shortcut icon" href="images/favicon.ico">

	<!-- Google Webfonts -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,700,600italic,700italic,800,800italic,300italic,300" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Sanchez:400,400italic" rel="stylesheet">

	<!--[if lt IE 9]>
	<script src="/js/libs/respond.min.js"></script>
	<![endif]-->

	<!-- Bootstrap core CSS -->
	<link href="css/bootstrap.css" rel="stylesheet">

	<!-- Theme Styles CSS-->
	<link href="css/style.css" rel="stylesheet">
    <link href="css/theme-shop.css" rel="stylesheet">
	<link href="css/elements.css" rel="stylesheet">
	<link href="fonts/icomoon/iconmoon.css" rel="stylesheet">
    <link href="fonts/font-awesome/css/font-awesome.css" rel="stylesheet">
	
	<style type="text/css">
		body {
		    font-family: Sanchez;
		    font-weight: 400;
		    width: 20cm;
		    font-size: 10px;
		}

		td,th{padding: 3px 2px!important;}

		@media print
		{    
		    .no-print, .no-print *
		    {
		        display: none !important;
		    }
		}

	</style>

	<!--[if lt IE 9]>
	<script src="/js/libs/html5.js"></script>
	<![endif]-->

</head>

<body onload="window.print();" id="pages">

<div style="text-align: center" class="no-print">
<a class="btn btn-primary" href="../mov_mensal.php">VOLTAR</a>
</div>
<div class="body">
	<!-- Main content -->
	<div class="shop-form-wrap">
		
		<!-- Shop Content -->
		
		<div role="main" class="shop">
		
				<div class="">
				
				
					<div>
						<div class="form-group">
							<div>
								<h4> <?php echo 'TRAJETOS:'.date('m/Y', strtotime($entregas[1]['dt_termino'])); ?> </h4>
							</div>
							<div style="display: inline-block;margin-top: -10px;">
								<h6> <?php echo 'Emitido em '.date('d/m/Y H:i:s', strtotime($hoje['dt']));?> </h6>
							</div>							
						</div>
					</div>	
					
					
					<div class="featured-boxes">
						<div class="">
							<div class="featured-box featured-box-primary">
								<div class="box-content">

									<table  class="shop_table cart">
										
										<thead>
											<tr>
												<th class="product-quantity">
													Data
												</th>											
												<th class="product-quantity">
													Nr.OS
												</th>
												<th class="product-quantity">
													Cliente
												</th>
												<th class="product-quantity">
													Entregador
												</th>
												<th class="product-quantity">
													Status OS
												</th>
												<th class="product-quantity">
													Valor Previsto
												</th>	
												<th class="product-quantity">
													Valor Final 
												</th>														
											</tr>
										</thead>
											
										<tbody>
												$total_entrega=0;
											     <?php
													foreach($entregas as $entrega) {														
													$total_entrega=$total_entrega+1;
0;
										        	echo 
														'<tr class="cart_table_item">'.
															'<td class="product-quantity">'.date('d/m/Y H:i:s', strtotime($entrega['dt_termino'])).'</td>'.
															'<td class="product-quantity">'.$entrega['nu_ordem_serv'].'</td>'.
															'<td class="product-quantity">'.$entrega['nm_cliente'].'</td>'.
															'<td class="product-quantity">'.$entrega['nm_fantasia'].'</td>'.
															'<td class="product-quantity">'.$entrega['st_os'].'</td>'.
															'<td class="product-price">'.number_format($entrega['vlr_os_previsto'], 2, ',', '.').'</td>'.
															'<td class="product-price">'.number_format($entrega['vlr_os_final'], 2, ',', '.').'</td>'.
														'</tr>';										

										        	}
										        ?>

										</tbody>
										
										<tfoot>
											<tr>
												<th class="product-quantity">
													
												</th>
												<th class="product-quantity">
													
												</th>
												<th class="product-price">
													Total de entregas:
												</th>											
												<th class="product-price">
													<?php echo number_format($total_entrega, 2, ',', '.');?> <input type="hidden">
												</th>
											</tr>
										</tfoot>										
										
										
									</table>

								</div>
							</div>
						</div>
					</div>
					
				
					
		
				</div>
	

		</div>
		
	</div>
	<!-- Main content -->
</div>

<!-- JavaScript -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/fancybox/jquery.fancybox.pack.js"></script>
<script src="js/main.js"></script>


</body>
</html>