<?php
require 'ControllerBd.php';
require 'ControllerMail.php';

/**
* 
*/
class ControllerCliente extends ControllerBd
{	

	function __construct()
	{
		parent::__construct();
	}

	public function getPerfil() {

		$stmt = $this->conn->prepare("SELECT * FROM cliente WHERE id_cliente = :id_cliente");		
		$stmt->bindParam(':id_cliente', $_SESSION['id_cliente']);
		$stmt->execute();

		return $stmt->fetch();
	}

	public function find() {

		$result = $this->conn->query("SELECT * FROM cliente LIMIT 1");
		print_r($result->fetchAll());
	}

	public function add($dados) {

		$validaEmail = $this->validateEmail($dados['email']);

		if(!$this->validateObrigatorios($dados) || !empty($validaEmail))
			return 'Esse e-mail já esta em uso.';

		$sql = "INSERT INTO cliente(nm_cliente, email, celular, senha, st_ativo, dt_inclusao) VALUES (:nm_cliente, :email, :celular, :senha, 1, :dt_inclusao)";
		$stmt = $this->conn->prepare($sql);

		$data = date('Y-m-d H:i:s');
		
		$senha = md5($dados['senha']);
		$celular = isset($dados['celular']) ? $dados['celular'] : '';

		$stmt->bindParam(':nm_cliente', $dados['nome']);
		$stmt->bindParam(':email', $dados['email']);
		$stmt->bindParam(':celular', $celular);
		$stmt->bindParam(':senha', $senha);
		$stmt->bindParam(':dt_inclusao', $data);
		 
		$stmt->execute();

		return json_encode($this->login($dados));
	}

	public function update($dados) {

		$validaEmail = $this->validateEmail($dados['email']);

		if(!empty($validaEmail) && $validaEmail[0]['id_cliente'] != $_SESSION['id_cliente'])
			return 3;

		$sql = "UPDATE cliente SET nm_cliente=:nm_cliente, email=:email, celular=:celular, telefone=:telefone, endereco=:endereco, cpf_cnpj=:cpf_cnpj WHERE id_cliente = :id_cliente";

		$stmt = $this->conn->prepare($sql);

		$celular  = isset($dados['celular']) ? $dados['celular'] : '';
		$telefone = isset($dados['telefone']) ? $dados['telefone'] : '';
		$cpf_cnpj = isset($dados['documento']) ? $dados['documento'] : '';
		$endereco = isset($dados['endereco']) ? $dados['endereco'] : '';

		$stmt->bindParam(':nm_cliente', $dados['nome']);
		$stmt->bindParam(':email', $dados['email']);
		$stmt->bindParam(':celular', $celular);
		$stmt->bindParam(':telefone', $telefone);
		$stmt->bindParam(':endereco', $endereco);
		$stmt->bindParam(':cpf_cnpj', $cpf_cnpj);
		$stmt->bindParam(':id_cliente', $_SESSION['id_cliente']);
		 
		return $stmt->execute();
	}

	public function alterarSenha($dados) {

		$validaEmail = $this->validateEmail($dados['email']);

		if(empty($validaEmail))
			return 'Esse e-mail é inválido';

		$senha = rand(111111, 999999);

		$dados['senha'] = md5($senha);

		$sql = "UPDATE cliente SET senha = :senha WHERE email = :email";
		$stmt = $this->conn->prepare($sql);

		$stmt->bindParam(':email', $dados['email']);
		$stmt->bindParam(':senha', $dados['senha']);

		$stmt->execute();

		$dados['senha'] = $senha;

		$email = new ControllerMail;

		$dados_email = array(
			'from'     => array('suporte@ssentregas.com.br', 'Suporte'),
			'assunto'  => 'SSEntregas - Sua senha foi alterada',
			'mensagem' => 'Sua senha foi alterada para: '.$dados['senha'],
			'to'	   => array($dados['email'], "")
		);

		return $email->send($dados_email);
	}

	public function validateObrigatorios($dados) {

		$obrigatorios = array('email','nome','celular','senha');
		
		foreach ($obrigatorios as $obrigatorio) {

			$validado = false;

			foreach ($dados as $key => $value) {
				if($key == $obrigatorio && trim($value) != '') {
					$validado = true;
					break;
				}
			}

			if(!$validado)
				return false;
		}
		
		return true;
	}

	public function validateEmail($email) {

		if(!filter_var($email, FILTER_VALIDATE_EMAIL))
			return false;

		$stmt = $this->conn->prepare("SELECT * FROM cliente WHERE email = :email LIMIT 1");
		$stmt->bindParam(':email',$email);

		$stmt->execute();
		

		return $stmt->fetchAll();
	}

	public function login($dados) {
		
		$dados['senha'] = md5($dados['senha']);

		$stmt = $this->conn->prepare("SELECT id_cliente FROM cliente WHERE email = :email AND senha = :senha LIMIT 1");
		$stmt->bindParam(':email',$dados['email']);
		$stmt->bindParam(':senha',$dados['senha']);
		$stmt->execute();

		$id = $stmt->fetch();

		if(!empty($id)) {
			$_SESSION['id_cliente'] = $id['id_cliente'];
			return true;
		}

		return false;
		
	}

}

$t = new ControllerCliente();

switch ($_GET['action']) {
	case 'add':
		echo $t->add($_POST);
		break;
	case 'update':
		echo $t->update($_POST);
		break;
	case 'find':
		echo json_encode($t->find());
		break;
	case 'login':
		echo json_encode($t->login($_POST));
		break;
	case 'esqueci_senha':
		echo json_encode($t->alterarSenha($_POST));
		break;
	case 'getPerfil':
		echo json_encode($t->getPerfil());
		break;
}