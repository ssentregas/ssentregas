<?php
error_reporting(E_ALL);
session_start();

define('MYSQL_HOST', 'jjcs1db0.cvpeqnywkfxy.sa-east-1.rds.amazonaws.com');
define('MYSQL_USER', 'DB1_MasterUser');
define('MYSQL_PASSWORD', 'BD1Master16');
define('MYSQL_DB_NAME', 'ssentregas');

class ControllerBd
{
	public $conn;

	function __construct()
	{
		try {
			$this->conn = new PDO('mysql:host='.MYSQL_HOST.';dbname='.MYSQL_DB_NAME.';charset=utf8',MYSQL_USER,MYSQL_PASSWORD,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
		}
		catch ( PDOException $e ) {
    		///echo 'Erro ao conectar com o MySQL: ' . ;
    		die($e->getMessage());
		}

	}
}