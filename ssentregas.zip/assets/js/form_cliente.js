$(function() {

    var maskBehavior = function (val) {
        return val.replace(/\D/g, '').length === 11 ? '00-00000-0000' : '00-0000-00009';
    },
    options = {onKeyPress: function(val, e, field, options) {field.mask(maskBehavior.apply({}, arguments), options);}};

    $('[name="celular"]').mask(maskBehavior, options);

    $.ajax({
        url: 'php/ControllerCliente.php?action=getPerfil',
        success: function(e) {
            e = $.parseJSON(e);
            $('#cliente [name="nome"],#orcamento [name="nome"]').val(e.nm_cliente);
            $('.main-title__secondary').text(e.nm_cliente);
            $('#cliente [name="celular"],#orcamento [name="telefone"]').val(e.celular);
            $('#cliente [name="email"],#orcamento [name="email"]').val(e.email);
            $('#cliente [name="contato"]').val(e.contato);
            $('#cliente [name="endereco"]').val(e.endereco);
            $('#cliente [name="documento"]').val(e.cpf_cnpj);
        }
    });

    "use strict";

    /* ================================================
       jQuery Validate - Reset Defaults
       ================================================ */

    $.validator.setDefaults({
        highlight: function(element) {
            $(element).closest('.c-form-group').addClass('has-error');
        },
        unhighlight: function(element) {
            $(element).closest('.c-form-group').removeClass('has-error');
        },
        errorElement: 'small',
        errorClass: 'help-block',
        errorPlacement: function(error, element) {
            if (element.parent('.input-group').length) {
                error.insertAfter(element.parent());
            }
            if (element.parent('label').length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        }
    });

    /*  VALIDATE */

    $("#cliente").submit(function(e) {
        e.preventDefault();
    }).validate({
        rules: {
            nome: "required",
            celular: "required",
            email: {
                required: true,
                email: true
            }
        },
        messages: {
            nome: "Campo é obrigatório",
            celular: "Campo é obrigatório",
            email: "Campo é obrigatório",
        },
        submitHandler: function(form) {

            $("#js-cliente-btn").attr("disabled", true);

            /* 
            CHECK PAGE FOR REDIRECT (Thank you page)
            ---------------------------------------- */

            var redirect = $('#cliente').data('redirect');
            var noredirect = false;
            if (redirect == 'none' || redirect == "" || redirect == null) {
                noredirect = true;
            }

            $("#js-cliente-result").html('<div class="alert alert-warning">Por favor, aguarde...</div>');

            /* 
            FETCH SUCCESS / ERROR MSG FROM HTML DATA-ATTR
            --------------------------------------------- */

            var success_msg = $('#js-cliente-result').data('success-msg');
            var error_msg = $('#js-cliente-result').data('error-msg');

            var dataString = $(form).serialize();

            /* 
             AJAX POST
             --------- */

            $.ajax({
                type: "POST",
                data: dataString,
                url: "php/ControllerCliente.php?action=update",
                cache: false,
                success: function(d) {
                    $(".form-group").removeClass("has-success");
                    if (d == '1') {
                        if (noredirect) {
                            $('#js-cliente-result').fadeIn('slow').html('<div class="alert alert-success">' + success_msg + '</div>').delay(3000).fadeOut('slow');
                            $('#orcamento').trigger("reset");
                        } else {
                            window.location.href = redirect;
                        }
                    } else {

                        if(d == '3') {
                            error_msg = 'Este e-mail já esta em uso.';
                        }
                        
                        $('#js-cliente-result').fadeIn('slow').html('<div class="alert alert-danger">' + error_msg + '</div>').delay(6000).fadeOut('slow');
                    }
                    $("#js-cliente-btn").attr("disabled", false);
                }
            });
            return false;

        }
    });

})
