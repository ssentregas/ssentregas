<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'frankfkl1_wp');

/** MySQL database username */
define('DB_USER', 'frank_wp');

/** MySQL database password */
define('DB_PASSWORD', 'Joca7749@');

/** MySQL hostname */
define('DB_HOST', 'robb0283.publiccloud.com.br:3306');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',       'RoM4xqfTDKggFs5uY#K*(*as(UH4bT9jP#5ZnAGa@tvEc1DBQ97%22h5zUoGFo*c');
define('SECURE_AUTH_KEY',       'fER%wqp)7USo#8gZa&icR1)5HNRs7Oyms#s(#T^VAH%r(MCGQX^Nxmrtf0glTvJX');
define('LOGGED_IN_KEY',       'gDMd4TN20vMTG(LIY*iQT%9K9H#Zj26I@)D8C6#i00gLiVW)DNjcrFpt!umj(6bB');
define('NONCE_KEY',       'hj0%za7uH1E4CFBm*0@aBNaYGl%CfnEir097xyE(jtoW(I&8p8AzN0wXrA3gG9xC');
define('AUTH_SALT',       'n4y7x2*WZzAihS0a1tjoeHot@3BdN#Z5JpaWdaY7)4t%p1SpxVbPOloMM!(7O2NW');
define('SECURE_AUTH_SALT',       '&Sifcc&B^0Fq%C1jMC2%Iv956N2gIgJGWjU9!5fG19wsaZ09z(!(j8dRcN%fm1Cy');
define('LOGGED_IN_SALT',       'tK1D0i8SuFklE@P7ZZu2MKEhrP8@cof7nGeAJ9LMwiJnC@)MKxAnun2OtRdLPH#T');
define('NONCE_SALT',       'ynKo6IxH#I#O0DnMbZfk!vLfCTHPP(0etcaBrIPTlEjfvYBJb(XoMfSWY5a6*Jvp');
/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp1wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define( 'WP_ALLOW_MULTISITE', true );

define ('FS_METHOD', 'direct');
?>